package com.prpintra.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "pr_pintra_data";
    private static final String KEY_TASKS = "tasks";
    private final int purple = Color.rgb(99, 91, 255);
    private final int ink = Color.rgb(31, 35, 60);
    private final int muted = Color.rgb(112, 118, 145);
    private LinearLayout taskList;
    private TextView totalText, doneText, emptyText;
    private JSONArray tasks = new JSONArray();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        loadTasks();
        buildScreen();
        renderTasks();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 24, 20, 28);
        root.setBackgroundColor(Color.rgb(245, 246, 255));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = text("✦", 26, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(bg(purple, 18));
        header.addView(logo, new LinearLayout.LayoutParams(54, 54));
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(12, 0, 0, 0);
        titleBox.addView(text("PR Pintra", 24, ink, true));
        titleBox.addView(text("Teman belajar dan pengingat tugasmu", 12, muted, false));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);

        TextView welcome = text("Halo, pejuang sekolah! 👋", 21, ink, true);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.topMargin = 28;
        root.addView(welcome, wp);
        TextView sub = text("Atur PR-mu, selesaikan satu per satu.", 14, muted, false);
        root.addView(sub);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, 18, 0, 22);
        totalText = text("0\\nTotal tugas", 16, Color.WHITE, true);
        doneText = text("0\\nSelesai", 16, Color.WHITE, true);
        styleStat(totalText, Color.rgb(99, 91, 255));
        styleStat(doneText, Color.rgb(32, 174, 139));
        LinearLayout.LayoutParams s1 = new LinearLayout.LayoutParams(0, 88, 1);
        s1.rightMargin = 8;
        stats.addView(totalText, s1);
        LinearLayout.LayoutParams s2 = new LinearLayout.LayoutParams(0, 88, 1);
        s2.leftMargin = 8;
        stats.addView(doneText, s2);
        root.addView(stats);

        root.addView(text("Tambah pekerjaan rumah", 18, ink, true));
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(16, 16, 16, 16);
        form.setBackground(bg(Color.WHITE, 22));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = 12;
        root.addView(form, fp);

        EditText titleInput = new EditText(this);
        titleInput.setSingleLine(true);
        titleInput.setHint("Nama tugas (contoh: latihan matematika)");
        titleInput.setTextSize(14);
        titleInput.setPadding(14, 10, 14, 10);
        titleInput.setBackground(bg(Color.rgb(245, 246, 251), 14));
        form.addView(titleInput, new LinearLayout.LayoutParams(-1, 50));

        EditText subjectInput = new EditText(this);
        subjectInput.setSingleLine(true);
        subjectInput.setHint("Mata pelajaran");
        subjectInput.setTextSize(14);
        subjectInput.setPadding(14, 10, 14, 10);
        subjectInput.setBackground(bg(Color.rgb(245, 246, 251), 14));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, 50);
        ip.topMargin = 10;
        form.addView(subjectInput, ip);

        EditText dueInput = new EditText(this);
        dueInput.setSingleLine(true);
        dueInput.setHint("Deadline (contoh: 20 Nov 2026)");
        dueInput.setTextSize(14);
        dueInput.setPadding(14, 10, 14, 10);
        dueInput.setBackground(bg(Color.rgb(245, 246, 251), 14));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, 50);
        dp.topMargin = 10;
        form.addView(dueInput, dp);

        Button add = new Button(this);
        add.setText("＋  Tambahkan tugas");
        add.setTextColor(Color.WHITE);
        add.setAllCaps(false);
        add.setTextSize(14);
        add.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add.setBackground(bg(purple, 16));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, 52);
        ap.topMargin = 12;
        form.addView(add, ap);

        add.setOnClickListener(v -> {
            String title = titleInput.getText().toString().trim();
            String subject = subjectInput.getText().toString().trim();
            String due = dueInput.getText().toString().trim();
            if (title.isEmpty()) {
                titleInput.setError("Nama tugas wajib diisi");
                return;
            }
            JSONObject item = new JSONObject();
            try {
                item.put("title", title);
                item.put("subject", subject.isEmpty() ? "Umum" : subject);
                item.put("due", due.isEmpty() ? "Belum ditentukan" : due);
                item.put("done", false);
                item.put("created", System.currentTimeMillis());
                tasks.put(item);
            } catch (Exception ignored) {}
            saveTasks();
            titleInput.setText("");
            subjectInput.setText("");
            dueInput.setText("");
            renderTasks();
            Toast.makeText(this, "Tugas berhasil ditambahkan", Toast.LENGTH_SHORT).show();
        });

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        section.setPadding(0, 24, 0, 12);
        section.addView(text("Daftar tugas", 18, ink, true));
        root.addView(section);

        emptyText = text("Belum ada tugas. Tambahkan PR pertamamu di atas! ✨", 14, muted, false);
        emptyText.setGravity(Gravity.CENTER);
        emptyText.setPadding(12, 28, 12, 28);
        taskList = new LinearLayout(this);
        taskList.setOrientation(LinearLayout.VERTICAL);
        root.addView(emptyText);
        root.addView(taskList);

        TextView footer = text("PR Pintra • Semua tugas tersimpan di perangkatmu", 11, muted, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams foot = new LinearLayout.LayoutParams(-1, -2);
        foot.topMargin = 28;
        root.addView(footer, foot);

        setContentView(scroll);
    }

    private void styleStat(TextView view, int color) {
        view.setGravity(Gravity.CENTER);
        view.setBackground(bg(color, 20));
        view.setLineSpacing(5, 1f);
    }

    private void renderTasks() {
        taskList.removeAllViews();
        int completed = 0;
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject obj = tasks.optJSONObject(i);
            if (obj != null && obj.optBoolean("done")) completed++;
        }
        totalText.setText(tasks.length() + "\\nTotal tugas");
        doneText.setText(completed + "\\nSelesai");
        emptyText.setVisibility(tasks.length() == 0 ? View.VISIBLE : View.GONE);

        for (int i = tasks.length() - 1; i >= 0; i--) {
            final int index = i;
            JSONObject obj = tasks.optJSONObject(i);
            if (obj == null) continue;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(16, 14, 14, 12);
            card.setBackground(bg(Color.WHITE, 20));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = 10;
            taskList.addView(card, cp);

            LinearLayout line = new LinearLayout(this);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setOrientation(LinearLayout.HORIZONTAL);
            card.addView(line);

            CheckBox check = new CheckBox(this);
            check.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));
            check.setChecked(obj.optBoolean("done"));
            line.addView(check);
            LinearLayout labels = new LinearLayout(this);
            labels.setOrientation(LinearLayout.VERTICAL);
            labels.setPadding(6, 0, 6, 0);
            line.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
            TextView name = text(obj.optString("title"), 15, ink, true);
            if (obj.optBoolean("done")) name.setPaintFlags(name.getPaintFlags() | 16);
            labels.addView(name);
            labels.addView(text(obj.optString("subject", "Umum") + "  •  Deadline: " + obj.optString("due"), 12, muted, false));

            TextView del = text("Hapus", 12, Color.rgb(220, 70, 90), true);
            del.setPadding(8, 10, 4, 10);
            line.addView(del);
            check.setOnCheckedChangeListener((button, checked) -> {
                try { tasks.getJSONObject(index).put("done", checked); } catch (Exception ignored) {}
                saveTasks();
                renderTasks();
            });
            del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Hapus tugas?")
                .setMessage("Tugas ini akan dihapus dari daftar.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (dialog, which) -> {
                    JSONArray updated = new JSONArray();
                    for (int j = 0; j < tasks.length(); j++) if (j != index) updated.put(tasks.opt(j));
                    tasks = updated;
                    saveTasks();
                    renderTasks();
                }).show());
        }
    }

    private void loadTasks() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TASKS, "[]");
        try { tasks = new JSONArray(raw); } catch (Exception e) { tasks = new JSONArray(); }
    }

    private void saveTasks() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TASKS, tasks.toString()).apply();
    }
}
